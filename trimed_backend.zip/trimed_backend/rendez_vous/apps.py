from django.apps import AppConfig


class RendezVousConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rendez_vous'
    verbose_name = 'Gestion des Rendez-vous'
