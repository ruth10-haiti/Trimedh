from django.apps import AppConfig


class GestionTenantsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gestion_tenants'
    verbose_name = 'Gestion des Tenants'

