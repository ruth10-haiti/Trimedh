from django.apps import AppConfig


class FacturationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'facturation'
    verbose_name = 'Gestion de Facturation'
